<tr class="row_discount">
    <td width="25%">
        <input 
        	type="text" 
        	class="input_text" 
        	placeholder="<?php esc_html_e('10.5', 'ova-brw'); ?>" 
        	name="ovabrw_gd_adult_price[]" 
        	autocomplete="off" />
    </td>
    <td width="25%">
        <input 
        	type="text" 
        	class="input_text" 
        	placeholder="<?php esc_html_e('10.5', 'ova-brw'); ?>" 
        	name="ovabrw_gd_children_price[]" 
        	autocomplete="off" />
    </td>
    <td width="49%">
	    <input 
	    	type="text" 
	    	class="input_text ovabrw-global-duration short" 
	    	placeholder="<?php esc_html_e('1', 'ova-brw'); ?>" 
	    	name="ovabrw_gd_duration_min[]" 
	    	autocomplete="off" />
	    <input 
	    	type="text" 
	    	class="input_text ovabrw-global-duration short" 
	    	placeholder="<?php esc_html_e('2', 'ova-brw'); ?>" 
	    	name="ovabrw_gd_duration_max[]" 
	    	autocomplete="off" />
    </td>
    <td width="1%"><a href="#" class="delete">x</a></td>
</tr>